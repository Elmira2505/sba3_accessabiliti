const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".primary-nav");

menuButton.addEventListener("click", () => {
  const isOpen = menuButton.getAttribute("aria-expanded") === "true";
  menuButton.setAttribute("aria-expanded", String(!isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Open navigation menu" : "Close navigation menu");
  navigation.classList.toggle("is-open", !isOpen);
});

navigation.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navigation.classList.remove("is-open");
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open navigation menu");
  });
});

// Display controls: high contrast and text size.
const contrastButton = document.querySelector(".contrast-toggle");
contrastButton.addEventListener("click", () => {
  const enabled = document.body.classList.toggle("high-contrast");
  contrastButton.setAttribute("aria-pressed", String(enabled));
  contrastButton.innerHTML = `<span aria-hidden="true">◐</span> ${enabled ? "Standard Contrast" : "High Contrast"}`;
});

let fontScale = 1;
document.querySelectorAll(".font-button").forEach((button) => {
  button.addEventListener("click", () => {
    fontScale += button.dataset.font === "increase" ? 0.05 : -0.05;
    fontScale = Math.min(1.2, Math.max(0.9, fontScale));
    document.documentElement.style.setProperty("--base-font", `${16 * fontScale}px`);
  });
});

// Accessible front-end form validation demo. No backend is connected.
const form = document.querySelector("#contact-form");
const status = document.querySelector("#form-status");

function showError(field, message) {
  const error = document.querySelector(`#${field.id}-error`);
  field.setAttribute("aria-invalid", message ? "true" : "false");
  error.textContent = message;
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = form.elements.name;
  const email = form.elements.email;
  const message = form.elements.message;
  let valid = true;

  showError(name, "");
  showError(email, "");
  showError(message, "");
  status.textContent = "";

  if (name.value.trim().length < 2) {
    showError(name, "Please enter at least 2 characters for your name.");
    valid = false;
  }
  if (!email.validity.valid || !email.value.trim()) {
    showError(email, "Please enter a valid email address.");
    valid = false;
  }
  if (message.value.trim().length < 10) {
    showError(message, "Please enter a message with at least 10 characters.");
    valid = false;
  }

  if (!valid) {
    status.textContent = "Please review the highlighted fields.";
    form.querySelector('[aria-invalid="true"]').focus();
    return;
  }

  status.textContent = "Thank you! Your message has been checked. This demo form is not connected to a server.";
  form.reset();
  [name, email, message].forEach((field) => field.setAttribute("aria-invalid", "false"));
});
