# Accessible Design Co.

A responsive, multi-section website built for a front-end practice assignment.

## Files
- `index.html` — semantic page structure and English content
- `styles.css` — responsive layout, Flexbox, CSS Grid, breakpoints, focus states, and color themes
- `script.js` — mobile navigation, contrast toggle, text-size controls, and accessible demo form validation

## Run it
Open `index.html` in your browser. No build tools are required.

## Assignment features
- Semantic HTML landmarks and heading hierarchy
- Flexbox navigation and CSS Grid content cards
- Responsive breakpoints at 1024px and 600px (plus an intermediate tablet breakpoint)
- ARIA labels, expanded/pressed states, descriptions, and live form status
- Meaningful text alternative for the hero accessibility illustration
- Labeled form fields, validation feedback, keyboard focus styles, and skip link
- Reduced-motion preference support

## Note
The contact form is a front-end demonstration only. It validates input but does not send messages to a server. Portfolio projects and testimonials are sample content for a fictional company.
